//
// Created by 86157 on 2024/11/6.
//

#ifndef DRI_USART_H
#define DRI_USART_H

void dri_usart1_init(void);

#endif//DRI_USART_H
