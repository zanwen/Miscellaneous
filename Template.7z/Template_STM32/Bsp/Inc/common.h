//
// Created by 86157 on 2024/11/5.
//

#ifndef COMMON_H
#define COMMON_H

#include "stm32f4xx_rcc.h"

typedef struct {
    GPIO_TypeDef *port;
    uint32_t pin;
    uint32_t rcc_gpio;
} gpio_port_pin_t;

typedef void (*callback_t)(void);

#endif// COMMON_H
