#include "int_led.h"
#include "common.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "systick.h"

#define LED_SW_RCU_GPIO RCC_AHB1Periph_GPIOC
#define LED_SW_PORT GPIOC
#define LED_SW_PIN GPIO_Pin_6

#define LED1_RCU_GPIO RCC_AHB1Periph_GPIOD
#define LED1_PORT GPIOD
#define LED1_PIN GPIO_Pin_8

#define LED2_RCU_GPIO RCC_AHB1Periph_GPIOD
#define LED2_PORT GPIOD
#define LED2_PIN GPIO_Pin_9

#define LED3_RCU_GPIO RCC_AHB1Periph_GPIOD
#define LED3_PORT GPIOD
#define LED3_PIN GPIO_Pin_10

#define LED4_RCU_GPIO RCC_AHB1Periph_GPIOD
#define LED4_PORT GPIOD
#define LED4_PIN GPIO_Pin_11

#define LED5_RCU_GPIO RCC_AHB1Periph_GPIOD
#define LED5_PORT GPIOD
#define LED5_PIN GPIO_Pin_12

#define LED6_RCU_GPIO RCC_AHB1Periph_GPIOD
#define LED6_PORT GPIOD
#define LED6_PIN GPIO_Pin_13

#define LED7_RCU_GPIO RCC_AHB1Periph_GPIOD
#define LED7_PORT GPIOD
#define LED7_PIN GPIO_Pin_14

#define LED8_RCU_GPIO RCC_AHB1Periph_GPIOD
#define LED8_PORT GPIOD
#define LED8_PIN GPIO_Pin_15

#define ON Bit_RESET
#define OFF Bit_SET

static gpio_port_pin_t led_gpio[LED_SIZE] = {
        {LED1_PORT, LED1_PIN, LED1_RCU_GPIO},
        {LED2_PORT, LED2_PIN, LED2_RCU_GPIO},
        {LED3_PORT, LED3_PIN, LED3_RCU_GPIO},
        {LED4_PORT, LED4_PIN, LED4_RCU_GPIO},
        {LED5_PORT, LED5_PIN, LED5_RCU_GPIO},
        {LED6_PORT, LED6_PIN, LED6_RCU_GPIO},
        {LED7_PORT, LED7_PIN, LED7_RCU_GPIO},
        {LED8_PORT, LED8_PIN, LED8_RCU_GPIO}};

static void init_led_gpio(uint32_t rcc_gpio, GPIO_TypeDef *port, uint16_t pin);


void int_led_init(void) {
    init_led_gpio(LED_SW_RCU_GPIO, LED_SW_PORT, LED_SW_PIN);
    for (int i = 0; i < LED_SIZE; i++) {
        init_led_gpio(led_gpio[i].rcc_gpio, led_gpio[i].port, led_gpio[i].pin);
    }

    GPIO_ResetBits(LED_SW_PORT, LED_SW_PIN);
    int_led_off_all();
}
void int_led_trotting_horse_lamp(LED_NO start, LED_NO end,
                                 int32_t step, uint32_t delay_ms) {
    if (start <= end) {
        for (int32_t led_no = start; led_no <= end; led_no += step) {
            int_led_on(led_no);
            delay_1ms(delay_ms);
            int_led_off(led_no);
        }
    } else {
        for (int32_t led_no = start; led_no >= end; led_no -= step) {
            int_led_on(led_no);
            delay_1ms(delay_ms);
            int_led_off(led_no);
        }
    }
}

void int_led_waterfall_lamp(LED_NO start, LED_NO end, int32_t step, uint32_t delay_ms) {
    if (start <= end) {
        for (int32_t led_no = start; led_no <= end; led_no += step) {
            int_led_on(led_no);
            delay_1ms(delay_ms);
        }
    } else {
        for (int32_t led_no = start; led_no >= end; led_no -= step) {
            int_led_on(led_no);
            delay_1ms(delay_ms);
        }
    }
}

void int_led_on(LED_NO led_no) {
    GPIO_WriteBit(led_gpio[led_no].port, led_gpio[led_no].pin, ON);
}
void int_led_off(LED_NO led_no) {
    GPIO_WriteBit(led_gpio[led_no].port, led_gpio[led_no].pin, OFF);
}
void int_led_on_all() {
    for (uint32_t i = 0; i < LED_SIZE; i++) {
        GPIO_WriteBit(led_gpio[i].port, led_gpio[i].pin, ON);
    }
}
void int_led_off_all() {
    for (uint32_t i = 0; i < LED_SIZE; i++) {
        GPIO_WriteBit(led_gpio[i].port, led_gpio[i].pin, OFF);
    }
}

static void init_led_gpio(uint32_t rcc_gpio, GPIO_TypeDef *port, uint16_t pin) {
    RCC_AHB1PeriphClockCmd(rcc_gpio, ENABLE);
    GPIO_InitTypeDef st_init;
    st_init.GPIO_Pin = pin;
    st_init.GPIO_Mode = GPIO_Mode_OUT;
    st_init.GPIO_OType = GPIO_OType_PP;
    st_init.GPIO_Speed = GPIO_High_Speed;
    st_init.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(port, &st_init);
}
