
#include "string.h"
#include "task.h"
#include "uart.h"

char stack_a[1024] __attribute__((aligned(4)));
char stack_b[1024] __attribute__((aligned(4)));
char stack_c[1024] __attribute__((aligned(4)));

void task_fn(void *params) {
    char ch = (char)params;
    while (1) {
        putchar(ch);
    }
}

void task_c(void *params) {
    int i;
    int sum = 0;

    for (i = 0; i <= 100; i++)
        sum += i;

    while (1) {
        put_s_hex("sum = ", sum);
    }
}

int mymain() {
    crreateTask(task_fn, 'a', stack_a, 1024);
    crreateTask(task_fn, 'b', stack_b, 1024);
    crreateTask(task_c, 0, stack_c, 1024);
    startTask();
    while (1) {
    }
}
