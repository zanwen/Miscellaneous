#ifndef __TASK_H__
#define __TASK_H__

typedef void (*fp)(void *params);

extern int is_task_running;
extern int task_sp_table[];
extern int cur_task_id;
extern int task_cnt;

void crreateTask(fp task_function, void *params, int stackBaseAddr, int stackSize);
void startTask(void);

#endif /* __TASK_H__ */
