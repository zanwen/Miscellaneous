void LedInit(void);
void LedCtrl(int on);

