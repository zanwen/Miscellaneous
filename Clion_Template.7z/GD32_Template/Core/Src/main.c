#include "gd32f4xx.h"
#include "systick.h"
#include <stdio.h>
#include "gd32f4xx_rcu.h"

void GPIO_config() {
    // PB2=LED1
    rcu_periph_clock_enable(RCU_GPIOB);
    gpio_mode_set(GPIOB, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO_PIN_2);
    gpio_output_options_set(GPIOB, GPIO_OTYPE_PP, GPIO_OSPEED_25MHZ, GPIO_PIN_2);
    gpio_bit_reset(GPIOB, GPIO_PIN_2);

    // PA0=SW2
    rcu_periph_clock_enable(RCU_GPIOA);
    gpio_mode_set(RCU_GPIOA, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO_PIN_0);
}

int main(void) {
    systick_config();
    GPIO_config();

    FlagStatus prev_state = RESET;

    while (1) {
        FlagStatus state = gpio_input_bit_get(GPIOA, GPIO_PIN_0);
        if (state != prev_state) {
            prev_state = state;
            if (state == SET) {
                gpio_bit_set(GPIOB, GPIO_PIN_2);
            } else {
                gpio_bit_reset(GPIOB, GPIO_PIN_2);
            }
        }
        delay_1ms(50);
    }
}
